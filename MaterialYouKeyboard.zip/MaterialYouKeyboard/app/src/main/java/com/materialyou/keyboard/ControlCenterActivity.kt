package com.materialyou.keyboard

import android.content.ClipData
import android.content.Context
import android.content.SharedPreferences
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.DragEvent
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.pm.PackageInfoCompat
import androidx.core.os.LocaleListCompat
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.button.MaterialButton
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.color.MaterialColors
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch

class ControlCenterActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences
    private var taps = 0
    private var lastTap = 0L
    private var toast: Toast? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_control)
        prefs = getSharedPreferences(KeyboardService.PREFS, MODE_PRIVATE)

        findViewById<MaterialToolbar>(R.id.cc_toolbar).setNavigationOnClickListener { finish() }

        // language
        val group = findViewById<RadioGroup>(R.id.lang_group)
        group.check(
            when (prefs.getString(Loc.KEY, "system")) {
                "ru" -> R.id.lang_ru
                "en" -> R.id.lang_en
                else -> R.id.lang_system
            }
        )
        group.setOnCheckedChangeListener { _, id ->
            val v = when (id) {
                R.id.lang_ru -> "ru"
                R.id.lang_en -> "en"
                else -> "system"
            }
            if (v != prefs.getString(Loc.KEY, "system")) {
                prefs.edit().putString(Loc.KEY, v).apply()
                applyLanguage(v)
            }
        }

        // reset
        findViewById<View>(R.id.btn_reset).setOnClickListener {
            MaterialAlertDialogBuilder(this)
                .setTitle(R.string.reset_title)
                .setMessage(R.string.reset_msg)
                .setNegativeButton(R.string.cancel, null)
                .setPositiveButton(R.string.reset_ok) { _, _ -> resetAll() }
                .show()
        }

        // version + hidden settings (7 taps)
        val ver = findViewById<TextView>(R.id.version)
        val info = packageManager.getPackageInfo(packageName, 0)
        ver.text = getString(R.string.version_fmt, info.versionName ?: "", PackageInfoCompat.getLongVersionCode(info).toInt())
        ver.setOnClickListener { onVersionTap() }
    }

    private fun applyLanguage(v: String) {
        val tags = if (v == "system") LocaleListCompat.getEmptyLocaleList() else LocaleListCompat.forLanguageTags(v)
        AppCompatDelegate.setApplicationLocales(tags)
    }

    private fun resetAll() {
        val e = prefs.edit()
        for (k in listOf(
            "vibrate", "sound", "number_row", "autocap", "suggestions", "autocorrect", "clip_history",
            "clip_chip", "clip_mask", "plus", "key_height", "big_letters", "voice_enabled", "voice_lang", "lang_globe", "hard_sign_alt", Themes.KEY, "sym_in_123", "touch_guard",
            Layouts.CUSTOM, "layout_RU", "layout_EN", Loc.KEY
        )) e.remove(k)
        e.apply()
        applyLanguage("system")
        Toast.makeText(this, R.string.reset_done, Toast.LENGTH_SHORT).show()
        recreate()
    }

    private fun onVersionTap() {
        val now = System.currentTimeMillis()
        if (now - lastTap > 2000) taps = 0
        lastTap = now
        taps++
        toast?.cancel()
        if (taps >= 7) {
            taps = 0
            showAdvanced()
        } else if (taps >= 3) {
            toast = Toast.makeText(this, getString(R.string.dev_left, 7 - taps), Toast.LENGTH_SHORT).also { it.show() }
        }
    }

    // ------------------------------------------------------------ hidden: custom key layout

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun col(attr: Int, fb: Int): Int = MaterialColors.getColor(this, attr, fb)

    private fun showAdvanced() {
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), dp(4))
        }
        val sw = MaterialSwitch(this).apply {
            text = getString(R.string.custom_layout)
            textSize = 16f
            isChecked = Layouts.enabled(prefs)
        }
        content.addView(sw, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val editor = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = if (sw.isChecked) View.VISIBLE else View.GONE
        }
        content.addView(editor, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val tabs = MaterialButtonToggleGroup(this).apply {
            isSingleSelection = true
            isSelectionRequired = true
        }
        val bRu = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = "RU"
            id = View.generateViewId()
        }
        val bEn = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = "EN"
            id = View.generateViewId()
        }
        tabs.addView(bRu)
        tabs.addView(bEn)
        val tlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        tlp.topMargin = dp(12)
        tlp.gravity = Gravity.CENTER_HORIZONTAL
        editor.addView(tabs, tlp)

        val board = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val blp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        blp.topMargin = dp(12)
        editor.addView(board, blp)

        val hint = TextView(this).apply {
            text = getString(R.string.layout_hint)
            textSize = 12f
            setTextColor(col(com.google.android.material.R.attr.colorOnSurfaceVariant, 0xFF888888.toInt()))
        }
        val hlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        hlp.topMargin = dp(10)
        editor.addView(hint, hlp)

        val reset = MaterialButton(this, null, com.google.android.material.R.attr.materialButtonOutlinedStyle).apply {
            text = getString(R.string.layout_reset)
        }
        val rlp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        rlp.topMargin = dp(8)
        editor.addView(reset, rlp)

        var code = "RU"
        fun current(): List<String> = Layouts.saved(prefs, code) ?: Layouts.defaults(code)
        fun render() = renderBoard(board, code, current())
        tabs.addOnButtonCheckedListener { _, id, checked ->
            if (checked) {
                code = if (id == bRu.id) "RU" else "EN"
                render()
            }
        }
        reset.setOnClickListener {
            Layouts.save(prefs, code, Layouts.defaults(code))
            render()
        }
        sw.setOnCheckedChangeListener { _, on ->
            prefs.edit().putBoolean(Layouts.CUSTOM, on).apply()
            if (on) {
                for (c in listOf("RU", "EN")) if (Layouts.saved(prefs, c) == null) Layouts.save(prefs, c, Layouts.defaults(c))
                render()
            }
            editor.visibility = if (on) View.VISIBLE else View.GONE
        }
        tabs.check(bRu.id)

        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.adv_title)
            .setView(content)
            .setPositiveButton(R.string.close, null)
            .show()
    }

    private fun keyBg(selected: Boolean): GradientDrawable = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE
        cornerRadius = dp(10).toFloat()
        setColor(
            if (selected) col(com.google.android.material.R.attr.colorPrimaryContainer, 0xFFD0BCFF.toInt())
            else col(com.google.android.material.R.attr.colorSurfaceContainerHighest, 0xFF3B383E.toInt())
        )
    }

    private fun renderBoard(board: LinearLayout, code: String, rows: List<String>) {
        board.removeAllViews()
        val onSurface = col(com.google.android.material.R.attr.colorOnSurface, 0xFFE6E0E9.toInt())
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        val grid = ArrayList<List<TextView>>()
        var selected: TextView? = null

        fun persist() {
            Layouts.save(prefs, code, grid.map { r -> r.joinToString("") { it.text.toString().lowercase() } })
        }

        fun swap(a: TextView, b: TextView) {
            val t = a.text
            a.text = b.text
            b.text = t
            persist()
        }

        for (row in rows) {
            val line = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_HORIZONTAL
                weightSum = rows[0].length.toFloat()
            }
            val cells = ArrayList<TextView>()
            for (ch in row) {
                val tv = TextView(this).apply {
                    text = ch.toString().uppercase()
                    gravity = Gravity.CENTER
                    textSize = 16f
                    setTextColor(onSurface)
                    background = keyBg(false)
                }
                var downX = 0f
                var downY = 0f
                var dragging = false
                tv.setOnTouchListener { v, e ->
                    when (e.actionMasked) {
                        MotionEvent.ACTION_DOWN -> {
                            downX = e.x
                            downY = e.y
                            dragging = false
                        }
                        MotionEvent.ACTION_MOVE -> if (!dragging &&
                            (Math.abs(e.x - downX) > slop || Math.abs(e.y - downY) > slop)
                        ) {
                            dragging = true
                            v.parent?.requestDisallowInterceptTouchEvent(true)
                            val data = ClipData.newPlainText("key", (v as TextView).text)
                            v.startDragAndDrop(data, View.DragShadowBuilder(v), v, 0)
                            return@setOnTouchListener true
                        }
                    }
                    false
                }
                tv.setOnClickListener {
                    val s = selected
                    if (s == null) {
                        selected = tv
                        tv.background = keyBg(true)
                    } else {
                        s.background = keyBg(false)
                        selected = null
                        if (s !== tv) swap(s, tv)
                    }
                }
                tv.setOnDragListener { v, ev ->
                    when (ev.action) {
                        DragEvent.ACTION_DRAG_STARTED -> {
                            if (ev.localState === v) v.alpha = 0.35f
                            true
                        }
                        DragEvent.ACTION_DRAG_ENTERED -> {
                            if (ev.localState !== v) v.background = keyBg(true)
                            true
                        }
                        DragEvent.ACTION_DRAG_EXITED -> {
                            v.background = keyBg(false)
                            true
                        }
                        DragEvent.ACTION_DROP -> {
                            val src = ev.localState as? TextView
                            if (src != null && src !== v) swap(src, v as TextView)
                            true
                        }
                        DragEvent.ACTION_DRAG_ENDED -> {
                            v.alpha = 1f
                            v.background = keyBg(false)
                            true
                        }
                        else -> true
                    }
                }
                val lp = LinearLayout.LayoutParams(0, dp(44), 1f)
                lp.setMargins(dp(2), dp(2), dp(2), dp(2))
                line.addView(tv, lp)
                cells.add(tv)
            }
            grid.add(cells)
            board.addView(line, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
    }
}
