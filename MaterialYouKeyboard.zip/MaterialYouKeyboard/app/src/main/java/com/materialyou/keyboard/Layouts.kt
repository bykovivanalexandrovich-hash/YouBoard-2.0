package com.materialyou.keyboard

import android.content.SharedPreferences

/** Letter rows of the keyboard layouts, with support for a user-defined arrangement. */
object Layouts {
    val RU_ROWS = listOf("йцукенгшщзхъ", "фывапролджэ", "ячсмитьбю")
    val UK_ROWS = listOf("йцукенгшщзхї", "фівапролджє", "ячсмитьбю")
    val EN_ROWS = listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")

    const val CUSTOM = "custom_layout"

    fun defaults(code: String): List<String> = when (code) {
        "RU" -> RU_ROWS
        "UK" -> UK_ROWS
        else -> EN_ROWS
    }

    fun enabled(p: SharedPreferences): Boolean = p.getBoolean(CUSTOM, false)

    /** Rows to show: the saved custom arrangement if it is valid, otherwise the defaults. */
    fun rows(p: SharedPreferences, code: String): List<String> {
        val def = defaults(code)
        if (!enabled(p)) return def
        return saved(p, code) ?: def
    }

    /** The saved arrangement for [code] (even when the custom mode is off), or null if absent/invalid. */
    fun saved(p: SharedPreferences, code: String): List<String>? {
        val def = defaults(code)
        val r = p.getString("layout_$code", null)?.split("|") ?: return null
        if (r.size != def.size || r.indices.any { r[it].length != def[it].length }) return null
        if (r.joinToString("").toList().sorted() != def.joinToString("").toList().sorted()) return null
        return r
    }

    fun save(p: SharedPreferences, code: String, rows: List<String>) {
        p.edit().putString("layout_$code", rows.joinToString("|")).apply()
    }

    fun signature(p: SharedPreferences): String =
        if (!enabled(p)) "d" else rows(p, "RU").joinToString("") + rows(p, "UK").joinToString("") + rows(p, "EN").joinToString("")
}
