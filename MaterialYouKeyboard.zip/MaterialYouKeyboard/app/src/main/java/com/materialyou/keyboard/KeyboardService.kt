package com.materialyou.keyboard

import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.InputType
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.graphics.ColorUtils
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.color.DynamicColors
import com.google.android.material.color.MaterialColors
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

class KeyboardService : InputMethodService() {

    companion object {
        const val PREFS = "keyboard_prefs"
        private val SYMBOL_ROWS = listOf("1234567890", "@#\$%&-+()/", "=*\"':;!?")
        private const val SEPARATORS = ".,!?;:"
    }

    private enum class Lang(val code: String, val title: String, val rows: List<String>, val asset: String) {
        RU("RU", "Русский", listOf("йцукенгшщзхъ", "фывапролджэ", "ячсмитьбю"), "dict_ru.txt"),
        EN("EN", "English", listOf("qwertyuiop", "asdfghjkl", "zxcvbnm"), "dict_en.txt")
    }

    private enum class Shift { OFF, ON, CAPS }

    private class Morph(
        val d: GradientDrawable,
        val n: FloatArray,
        val p: FloatArray,
        var color: Int,
        var pressedColor: Int
    ) {
        val cur: FloatArray = n.copyOf()
        var curColor: Int = color
        var anim: ValueAnimator? = null
    }

    private class Key(
        val root: FrameLayout,
        val face: FrameLayout,
        val label: TextView?,
        val icon: ImageView?,
        val morph: Morph
    )

    private class Cat(val tab: String, val items: List<String>)
    private class Correction(val original: String, val fixed: String, val sep: String)
    private class Sugg(val list: List<String>, val autoFix: String?)

    private class Palette(private val c: Context) {
        private fun col(attr: Int, fallback: Long): Int =
            MaterialColors.getColor(c, attr, fallback.toInt())

        val bg = col(com.google.android.material.R.attr.colorSurfaceContainer, 0xFF2B2930)
        val letter = col(com.google.android.material.R.attr.colorSurfaceContainerHigh, 0xFF36343B)
        val space = col(com.google.android.material.R.attr.colorSurfaceContainerHighest, 0xFF3B383E)
        val function = col(com.google.android.material.R.attr.colorSecondaryContainer, 0xFF4A4458)
        val onFunction = col(com.google.android.material.R.attr.colorOnSecondaryContainer, 0xFFE8DEF8)
        val tertiary = col(com.google.android.material.R.attr.colorTertiaryContainer, 0xFF633B48)
        val onTertiary = col(com.google.android.material.R.attr.colorOnTertiaryContainer, 0xFFFFD8E4)
        val primary = col(com.google.android.material.R.attr.colorPrimary, 0xFFD0BCFF)
        val onPrimary = col(com.google.android.material.R.attr.colorOnPrimary, 0xFF381E72)
        val pressed = col(com.google.android.material.R.attr.colorPrimaryContainer, 0xFF4F378B)
        val onSurface = col(com.google.android.material.R.attr.colorOnSurface, 0xFFE6E0E9)
        val onSurfaceVariant = col(com.google.android.material.R.attr.colorOnSurfaceVariant, 0xFFCAC4D0)
    }

    private val handler = Handler(Looper.getMainLooper())
    private val prefs: SharedPreferences by lazy { getSharedPreferences(PREFS, MODE_PRIVATE) }
    private val audio: AudioManager? by lazy { getSystemService(AudioManager::class.java) }
    private val imm: InputMethodManager? by lazy { getSystemService(InputMethodManager::class.java) }
    private val exec = Executors.newSingleThreadExecutor()
    private val dicts = HashMap<String, WordDict>()
    private val userWords: MutableSet<String> = ConcurrentHashMap.newKeySet()
    private lateinit var clipStore: ClipStore
    private var clipboard: ClipboardManager? = null
    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener { captureClip() }

    // state
    private var lang = Lang.RU
    private var symbols = false
    private var shift = Shift.OFF
    private var renderedShift: Shift? = null
    private var lastShiftTap = 0L
    private var plus = false

    // typing state
    private val word = StringBuilder()
    private var lastOwnEdit = 0L
    private var lastCorrection: Correction? = null
    private var skipCorrect: String? = null
    private var canDoubleSpace = false
    private var lastSpaceTime = 0L
    private var suggestOn = true
    private var autocorrectOn = true
    private var suggestionsAllowed = true
    @Volatile
    private var suggestGen = 0
    private var suggestFor: String? = null
    private var autoFix: String? = null
    private val resyncRun = Runnable { resyncWord() }

    // views
    private var rootView: View? = null
    private var viewCtx: Context? = null
    private var palette: Palette? = null
    private var builtSig = ""
    private var navColor = 0
    private var faceH = 0f
    private var keysBox: LinearLayout? = null
    private var contentFrame: FrameLayout? = null
    private var panel: View? = null
    private var panelKind: String? = null
    private var clipList: LinearLayout? = null
    private var clipBtn: View? = null
    private var symBtn: View? = null
    private var altOverlay: LinearLayout? = null
    private val altChips = ArrayList<TextView>()
    private var altValues: List<String> = emptyList()
    private var altSel = 0
    private var menuKey: Key? = null
    private var menuOverlay: LinearLayout? = null
    private var emojiCache: List<Cat>? = null
    private val letterKeys = mutableListOf<Pair<TextView, String>>()
    private val suggestCells = mutableListOf<TextView>()
    private var shiftKey: Key? = null

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate() {
        super.onCreate()
        clipStore = ClipStore(prefs)
        userWords.addAll(prefs.getStringSet("user_words", emptySet()) ?: emptySet())
        clipboard = getSystemService(ClipboardManager::class.java)
        clipboard?.addPrimaryClipChangedListener(clipListener)
        ensureDict(Lang.RU)
        ensureDict(Lang.EN)
    }

    override fun onDestroy() {
        clipboard?.removePrimaryClipChangedListener(clipListener)
        exec.shutdown()
        super.onDestroy()
    }

    override fun onCreateInputView(): View {
        val v = buildKeyboard()
        rootView = v
        builtSig = signature()
        return v
    }

    override fun onEvaluateFullscreenMode(): Boolean = false

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        suggestOn = prefs.getBoolean("suggestions", true)
        autocorrectOn = suggestOn && prefs.getBoolean("autocorrect", true)
        suggestionsAllowed = true
        var wantSymbols = symbols
        if (info != null) {
            val cls = info.inputType and InputType.TYPE_MASK_CLASS
            val variation = info.inputType and InputType.TYPE_MASK_VARIATION
            if (cls != InputType.TYPE_CLASS_TEXT) suggestionsAllowed = false
            if (cls == InputType.TYPE_CLASS_TEXT) {
                when (variation) {
                    InputType.TYPE_TEXT_VARIATION_PASSWORD,
                    InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD,
                    InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD,
                    InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS,
                    InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS,
                    InputType.TYPE_TEXT_VARIATION_URI -> suggestionsAllowed = false
                }
                if ((info.inputType and InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS) != 0) suggestionsAllowed = false
            }
            if (!restarting) {
                wantSymbols = cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE
            }
        }
        var needRebuild = rootView == null || builtSig != signature()
        if (wantSymbols != symbols) {
            symbols = wantSymbols
            needRebuild = true
        }
        if (needRebuild) rebuild() else if (panelKind != null) hidePanel(false)
        if (shift != Shift.CAPS) shift = Shift.OFF
        autoCapIfNeeded()
        refreshShift()
        applyNavBar()
        resyncWord()
        captureClip()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        handler.removeCallbacksAndMessages(null)
        word.setLength(0)
        lastCorrection = null
    }

    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int, newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        // Cursor moved or the app changed the text on its own (not through our key presses).
        if (SystemClock.uptimeMillis() - lastOwnEdit > 350) {
            resyncWord()
            if (shift == Shift.OFF) {
                autoCapIfNeeded()
                refreshShift()
            }
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (rootView != null) {
            rebuild()
            applyNavBar()
        }
    }

    private fun signature(): String =
        "${prefs.getBoolean("number_row", true)}|${prefs.getInt("key_height", 48)}|" +
                "${prefs.getBoolean("plus", false)}|${prefs.getBoolean("suggestions", true)}|" +
                "${prefs.getBoolean("clip_history", true)}"

    private fun rebuild() {
        panelKind = null
        panel = null
        val v = buildKeyboard()
        rootView = v
        builtSig = signature()
        setInputView(v)
    }

    private fun applyNavBar() {
        try {
            val w = window?.window ?: return
            w.navigationBarColor = navColor
            WindowCompat.getInsetsController(w, w.decorView).isAppearanceLightNavigationBars =
                ColorUtils.calculateLuminance(navColor) > 0.5
        } catch (_: Exception) {
        }
    }

    // ---------------------------------------------------------------- building UI

    private fun dp(v: Int): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    private fun colorsFor(p: Palette, kind: KeyKind): Pair<Int, Int> = when (kind) {
        KeyKind.LETTER -> p.letter to p.onSurface
        KeyKind.FUNCTION, KeyKind.SHIFT, KeyKind.BACKSPACE -> p.function to p.onFunction
        KeyKind.SPACE -> if (plus) p.tertiary to p.onTertiary else p.space to p.onSurfaceVariant
        KeyKind.ENTER -> p.primary to p.onPrimary
    }

    private fun pressedColorFor(p: Palette, kind: KeyKind): Int =
        if (kind == KeyKind.ENTER) ColorUtils.blendARGB(p.primary, p.onPrimary, 0.25f) else p.pressed

    private fun makeKey(
        c: Context,
        p: Palette,
        kind: KeyKind,
        label: String? = null,
        hint: String? = null,
        icon: Int? = null,
        textSp: Float = 22f
    ): Key {
        val (bg, fg) = colorsFor(p, kind)
        val density = resources.displayMetrics.density
        val n = KeyShapes.normal(kind, plus, faceH, density)
        val pr = KeyShapes.pressed(kind, plus, faceH, density)
        val d = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            setColor(bg)
            cornerRadii = n.copyOf()
        }
        val morph = Morph(d, n, pr, bg, pressedColorFor(p, kind))

        // root = full touch cell (no dead zones between keys); face = visible rounded key
        val root = FrameLayout(c)
        val face = FrameLayout(c)
        face.background = d
        val flp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        flp.setMargins(dp(2), dp(3), dp(2), dp(3))
        root.addView(face, flp)

        var lbl: TextView? = null
        var ic: ImageView? = null
        if (label != null) {
            lbl = TextView(c).apply {
                text = label
                setTextColor(fg)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, textSp)
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                gravity = Gravity.CENTER
                includeFontPadding = false
            }
            face.addView(lbl, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
        if (icon != null) {
            ic = ImageView(c).apply {
                setImageResource(icon)
                setColorFilter(fg)
            }
            face.addView(ic, FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER))
        }
        if (hint != null) {
            val h = TextView(c).apply {
                text = hint
                setTextColor(p.onSurfaceVariant)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
                includeFontPadding = false
            }
            val lp = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP or Gravity.END
            )
            lp.setMargins(0, dp(3), dp(6), 0)
            face.addView(h, lp)
        }
        return Key(root, face, lbl, ic, morph)
    }

    private fun setKeyColor(k: Key, color: Int) {
        k.morph.color = color
        if (k.morph.anim?.isRunning != true) {
            k.morph.curColor = color
            k.morph.d.setColor(color)
        }
    }

    private fun charKey(c: Context, p: Palette, ch: String, hint: String?, letter: Boolean, alts: List<String>?): Key {
        val k = makeKey(c, p, KeyKind.LETTER, label = ch, hint = hint)
        if (letter) letterKeys.add(k.label!! to ch)
        val altList = alts ?: emptyList()
        val longAction: (() -> Unit)? = if (altList.size == 1) {
            { replaceLast(altList[0]) }
        } else null
        attachTouch(k, onLong = longAction, alts = if (altList.size > 1) altList else null) {
            typeText(if (letter && shift != Shift.OFF) ch.uppercase() else ch)
        }
        return k
    }

    /** Key for the letter/symbol rows with long-press alternatives. */
    private fun rowKey(c: Context, p: Palette, ch: String, row: Int, index: Int, numberRow: Boolean): Key {
        if (symbols) return charKey(c, p, ch, null, false, null)
        val alts = ArrayList<String>()
        if (lang == Lang.RU && ch == "е") alts.add("ё")
        if (row == 0 && !numberRow && index < 10) alts.add("1234567890"[index].toString())
        return charKey(c, p, ch, if (alts.isEmpty()) null else alts.joinToString(""), true, if (alts.isEmpty()) null else alts)
    }

    private fun buildKeyboard(): View {
        val c = DynamicColors.wrapContextIfAvailable(this, R.style.Theme_KeyboardView)
        viewCtx = c
        val p = Palette(c)
        palette = p
        navColor = p.bg
        plus = prefs.getBoolean("plus", false)
        letterKeys.clear()
        suggestCells.clear()
        shiftKey = null
        renderedShift = null
        panel = null
        panelKind = null
        clipList = null
        clipBtn = null
        symBtn = null
        altOverlay = null
        menuOverlay = null
        menuKey = null

        val keyH = dp(prefs.getInt("key_height", 48))
        faceH = (keyH - dp(6)).toFloat()
        val numberRow = prefs.getBoolean("number_row", true)
        val rows = if (symbols) SYMBOL_ROWS else lang.rows
        val maxKeys = rows[0].length
        val showBar = prefs.getBoolean("suggestions", true) || prefs.getBoolean("clip_history", true)

        val root = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(p.bg)
            setPadding(dp(4), dp(4), dp(4), dp(6))
            clipChildren = false
            clipToPadding = false
        }
        val basePad = dp(6)
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val nav = insets.getInsets(WindowInsetsCompat.Type.navigationBars()).bottom
            v.setPadding(dp(4), dp(4), dp(4), basePad + nav)
            insets
        }

        if (showBar) {
            root.addView(buildTopBar(c, p), LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(42)))
        }

        val frame = FrameLayout(c).apply {
            clipChildren = false
            clipToPadding = false
        }
        contentFrame = frame
        val box = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL }
        keysBox = box
        frame.addView(box, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(frame, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        fun newRow(): LinearLayout {
            val r = LinearLayout(c).apply {
                orientation = LinearLayout.HORIZONTAL
                weightSum = maxKeys.toFloat()
            }
            box.addView(r, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, keyH))
            return r
        }

        fun LinearLayout.addKey(k: Key, w: Float) {
            addView(k.root, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, w))
        }

        fun LinearLayout.addSpacer(w: Float) {
            addView(View(c), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, w))
        }

        // number row
        if (!symbols && numberRow) {
            val r = newRow()
            "1234567890".forEach { d ->
                r.addKey(charKey(c, p, d.toString(), null, false, null), maxKeys / 10f)
            }
        }

        // letter / symbol rows
        rows.forEachIndexed { i, chars ->
            val r = newRow()
            if (i == 2) {
                val rest = maxKeys - chars.length
                if (!symbols) {
                    val sk = makeKey(c, p, KeyKind.SHIFT, icon = R.drawable.ic_shift)
                    attachTouch(sk) { onShiftTap() }
                    shiftKey = sk
                    r.addKey(sk, rest / 2f)
                }
                chars.forEachIndexed { idx, ch -> r.addKey(rowKey(c, p, ch.toString(), i, idx, numberRow), 1f) }
                val bs = makeKey(c, p, KeyKind.BACKSPACE, icon = R.drawable.ic_backspace)
                attachTouch(bs, repeat = true) { backspace() }
                r.addKey(bs, if (symbols) rest.toFloat() else rest / 2f)
            } else {
                val pad = (maxKeys - chars.length) / 2f
                if (pad > 0f) r.addSpacer(pad)
                chars.forEachIndexed { idx, ch -> r.addKey(rowKey(c, p, ch.toString(), i, idx, numberRow), 1f) }
                if (pad > 0f) r.addSpacer(pad)
            }
        }

        // bottom row
        val bottom = newRow()

        val modeKey = makeKey(c, p, KeyKind.FUNCTION, label = if (symbols) "ABC" else "?123", textSp = 15f)
        attachTouch(modeKey, fireOnDown = false) {
            symbols = !symbols
            word.setLength(0)
            rebuild()
        }
        bottom.addKey(modeKey, 1.25f)

        val menuK = makeKey(c, p, KeyKind.FUNCTION, icon = R.drawable.ic_menu)
        menuKey = menuK
        attachTouch(menuK, fireOnDown = false, onLong = { imm?.showInputMethodPicker() }) { toggleMenu(menuK) }
        bottom.addKey(menuK, 1f)

        bottom.addKey(charKey(c, p, ",", null, false, null), 1f)

        val spaceKey = makeKey(c, p, KeyKind.SPACE, label = lang.title, textSp = 14f)
        attachTouch(spaceKey) { typeText(" ") }
        bottom.addKey(spaceKey, maxKeys - 5.5f)

        bottom.addKey(charKey(c, p, ".", null, false, null), 1f)

        val enterKey = makeKey(c, p, KeyKind.ENTER, icon = R.drawable.ic_enter)
        attachTouch(enterKey) { pressEnter() }
        bottom.addKey(enterKey, 1.25f)

        refreshShift()
        clearSuggestions()
        return root
    }

    private fun iconButton(c: Context, p: Palette, res: Int, tint: Int, onClick: () -> Unit): FrameLayout {
        val b = FrameLayout(c)
        val tv = TypedValue()
        c.theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, tv, true)
        if (tv.resourceId != 0) b.setBackgroundResource(tv.resourceId)
        val iv = ImageView(c).apply {
            setImageResource(res)
            setColorFilter(tint)
        }
        b.addView(iv, FrameLayout.LayoutParams(dp(22), dp(22), Gravity.CENTER))
        b.setOnClickListener {
            feedback(it)
            onClick()
        }
        return b
    }

    private fun symButton(c: Context, p: Palette): FrameLayout {
        val b = FrameLayout(c)
        val tv = TypedValue()
        c.theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, tv, true)
        if (tv.resourceId != 0) b.setBackgroundResource(tv.resourceId)
        val t = TextView(c).apply {
            text = "\u03A9"
            setTextColor(p.onSurfaceVariant)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            gravity = Gravity.CENTER
        }
        b.addView(t, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        b.setOnClickListener {
            feedback(it)
            showGridPanel("sym")
        }
        return b
    }

    private fun buildTopBar(c: Context, p: Palette): View {
        val bar = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val clip = iconButton(c, p, R.drawable.ic_clipboard, p.onSurfaceVariant) { toggleClipPanel() }
        clipBtn = clip
        bar.addView(clip, LinearLayout.LayoutParams(dp(44), ViewGroup.LayoutParams.MATCH_PARENT))

        for (i in 0 until 3) {
            val tv = TextView(c).apply {
                gravity = Gravity.CENTER
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                setTextColor(p.onSurface)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                setPadding(dp(8), 0, dp(8), 0)
            }
            tv.setOnClickListener { onSuggestionTap(i) }
            val lp = LinearLayout.LayoutParams(0, dp(34), 1f)
            lp.setMargins(dp(2), 0, dp(2), 0)
            bar.addView(tv, lp)
            suggestCells.add(tv)
        }

        val sym = symButton(c, p)
        symBtn = sym
        bar.addView(sym, LinearLayout.LayoutParams(dp(40), ViewGroup.LayoutParams.MATCH_PARENT))

        val settings = iconButton(c, p, R.drawable.ic_settings, p.onSurfaceVariant) {
            val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
        }
        bar.addView(settings, LinearLayout.LayoutParams(dp(44), ViewGroup.LayoutParams.MATCH_PARENT))
        return bar
    }

    // ---------------------------------------------------------------- touch handling

    private fun pressVisual(k: Key, down: Boolean) {
        val m = k.morph
        m.anim?.cancel()
        val toR = if (down) m.p else m.n
        val toC = if (down) m.pressedColor else m.color
        if (!plus) {
            for (i in 0 until 8) m.cur[i] = toR[i]
            m.curColor = toC
            m.d.cornerRadii = m.cur.copyOf()
            m.d.setColor(toC)
            return
        }
        val fromR = m.cur.copyOf()
        val fromC = m.curColor
        val eval = ArgbEvaluator()
        val a = ValueAnimator.ofFloat(0f, 1f)
        a.duration = if (down) 80L else 260L
        a.interpolator = if (down) DecelerateInterpolator() else OvershootInterpolator(1.8f)
        a.addUpdateListener { an ->
            val f = an.animatedValue as Float
            for (i in 0 until 8) m.cur[i] = maxOf(0f, fromR[i] + (toR[i] - fromR[i]) * f)
            m.curColor = eval.evaluate(f.coerceIn(0f, 1f), fromC, toC) as Int
            m.d.cornerRadii = m.cur.copyOf()
            m.d.setColor(m.curColor)
        }
        m.anim = a
        a.start()

        val s = if (down) 0.9f else 1f
        k.face.animate().cancel()
        k.face.animate()
            .scaleX(s).scaleY(s)
            .setDuration(if (down) 80L else 240L)
            .setInterpolator(if (down) DecelerateInterpolator() else OvershootInterpolator(2.2f))
            .start()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun attachTouch(
        k: Key,
        repeat: Boolean = false,
        fireOnDown: Boolean = true,
        onLong: (() -> Unit)? = null,
        alts: List<String>? = null,
        onTap: () -> Unit
    ) {
        var longDone = false
        var cancelled = false
        var altMode = false
        val longRun = object : Runnable {
            override fun run() {
                if (repeat) {
                    onTap()
                    handler.postDelayed(this, 45)
                } else if (alts != null) {
                    longDone = true
                    altMode = true
                    feedback(k.root)
                    pressVisual(k, false)
                    showAlts(k, alts)
                } else if (onLong != null) {
                    longDone = true
                    feedback(k.root)
                    pressVisual(k, false)
                    onLong()
                }
            }
        }
        k.root.setOnTouchListener { view, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    longDone = false
                    cancelled = false
                    altMode = false
                    if (k !== menuKey) hideMenu()
                    pressVisual(k, true)
                    feedback(view)
                    if (fireOnDown) onTap()
                    if (repeat) {
                        handler.postDelayed(longRun, 400)
                    } else if (onLong != null || alts != null) {
                        handler.postDelayed(longRun, 380)
                    }
                }
                MotionEvent.ACTION_MOVE -> {
                    if (altMode) {
                        updateAlts(ev.rawX)
                    } else {
                        val slack = dp(14)
                        if (!cancelled && (ev.x < -slack || ev.x > view.width + slack ||
                                    ev.y < -slack || ev.y > view.height + slack)
                        ) {
                            cancelled = true
                            handler.removeCallbacks(longRun)
                            pressVisual(k, false)
                        }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    handler.removeCallbacks(longRun)
                    if (altMode) {
                        altMode = false
                        val sel = altValues.getOrNull(altSel)
                        hideAlts()
                        if (sel != null) replaceLast(sel)
                    } else {
                        if (!cancelled && !longDone) pressVisual(k, false)
                        if (!fireOnDown && !longDone && !cancelled) onTap()
                    }
                }
                MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(longRun)
                    if (altMode) {
                        altMode = false
                        hideAlts()
                    }
                    pressVisual(k, false)
                }
            }
            true
        }
    }

    private fun switchLang() {
        lang = if (lang == Lang.RU) Lang.EN else Lang.RU
        symbols = false
        word.setLength(0)
        rebuild()
    }

    /** Small two-button menu above the menu key: emoji and language. */
    private fun toggleMenu(k: Key) {
        if (menuOverlay != null) {
            hideMenu()
            return
        }
        val c = viewCtx ?: return
        val p = palette ?: return
        val frame = contentFrame ?: return
        val ov = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(4), dp(4), dp(4), dp(4))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(22).toFloat()
                setColor(p.space)
            }
            elevation = dp(8).toFloat()
        }
        fun chip(label: String, sp: Float, action: () -> Unit) {
            val tv = TextView(c).apply {
                text = label
                gravity = Gravity.CENTER
                setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
                setTextColor(p.onFunction)
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(18).toFloat()
                    setColor(p.function)
                }
            }
            tv.setOnClickListener {
                feedback(it)
                hideMenu()
                action()
            }
            val lp = LinearLayout.LayoutParams(dp(54), dp(44))
            lp.setMargins(dp(2), 0, dp(2), 0)
            ov.addView(tv, lp)
        }
        chip("\uD83D\uDE42", 22f) { showGridPanel("emoji") }
        chip(if (lang == Lang.RU) "EN" else "RU", 16f) { switchLang() }
        frame.addView(ov, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        ov.measure(
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val w = ov.measuredWidth
        val h = ov.measuredHeight
        val a = IntArray(2)
        val b = IntArray(2)
        k.root.getLocationOnScreen(a)
        frame.getLocationOnScreen(b)
        var x = a[0] - b[0] + k.root.width / 2 - w / 2
        x = x.coerceIn(0, maxOf(0, frame.width - w))
        val y = a[1] - b[1] - h - dp(2)
        ov.translationX = x.toFloat()
        ov.translationY = y.toFloat()
        ov.alpha = 0f
        ov.animate().alpha(1f).setDuration(120).start()
        menuOverlay = ov
    }

    private fun hideMenu() {
        menuOverlay?.let { contentFrame?.removeView(it) }
        menuOverlay = null
    }

    /** Popup with alternatives above a key (hold, slide, release). */
    private fun showAlts(k: Key, alts: List<String>) {
        val c = viewCtx ?: return
        val p = palette ?: return
        val frame = contentFrame ?: return
        hideAlts()
        val ov = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(4), dp(4), dp(4), dp(4))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(18).toFloat()
                setColor(p.space)
            }
            elevation = dp(8).toFloat()
        }
        altChips.clear()
        for (a in alts) {
            val tv = TextView(c).apply {
                text = a
                gravity = Gravity.CENTER
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            }
            ov.addView(tv, LinearLayout.LayoutParams(dp(46), dp(46)))
            altChips.add(tv)
        }
        altValues = alts
        altSel = 0
        frame.addView(ov, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        ov.measure(
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val w = ov.measuredWidth
        val h = ov.measuredHeight
        val a = IntArray(2)
        val b = IntArray(2)
        k.root.getLocationOnScreen(a)
        frame.getLocationOnScreen(b)
        var x = a[0] - b[0] + k.root.width / 2 - dp(4) - dp(23)
        x = x.coerceIn(0, maxOf(0, frame.width - w))
        val rootTop = rootView?.let { r ->
            val l = IntArray(2)
            r.getLocationOnScreen(l)
            l[1] - b[1]
        } ?: -dp(40)
        var y = a[1] - b[1] - h - dp(2)
        if (y < rootTop) y = rootTop
        ov.translationX = x.toFloat()
        ov.translationY = y.toFloat()
        altOverlay = ov
        paintAlts()
    }

    private fun paintAlts() {
        val p = palette ?: return
        for ((i, tv) in altChips.withIndex()) {
            if (i == altSel) {
                tv.setTextColor(p.onPrimary)
                tv.background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(14).toFloat()
                    setColor(p.primary)
                }
            } else {
                tv.setTextColor(p.onSurface)
                tv.background = null
            }
        }
    }

    private fun updateAlts(rawX: Float) {
        if (altChips.isEmpty()) return
        var best = 0
        var bestDist = Float.MAX_VALUE
        val loc = IntArray(2)
        for ((i, ch) in altChips.withIndex()) {
            ch.getLocationOnScreen(loc)
            val d = Math.abs(rawX - (loc[0] + ch.width / 2f))
            if (d < bestDist) {
                bestDist = d
                best = i
            }
        }
        if (best != altSel) {
            altSel = best
            paintAlts()
        }
    }

    private fun hideAlts() {
        altOverlay?.let { contentFrame?.removeView(it) }
        altOverlay = null
        altChips.clear()
    }

    private fun feedback(v: View) {
        if (prefs.getBoolean("vibrate", true)) {
            @Suppress("DEPRECATION")
            v.performHapticFeedback(
                HapticFeedbackConstants.KEYBOARD_TAP,
                HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING
            )
        }
        if (prefs.getBoolean("sound", false)) {
            audio?.playSoundEffect(AudioManager.FX_KEYPRESS_STANDARD, -1f)
        }
    }

    // ---------------------------------------------------------------- typing logic

    private fun norm(s: String): String = s.lowercase().replace('ё', 'е')

    private fun typeText(s: String) {
        val ic = currentInputConnection ?: return
        lastOwnEdit = SystemClock.uptimeMillis()
        val ch = if (s.length == 1) s[0] else null

        if (ch != null && (ch.isLetter() || (ch == '\'' && word.isNotEmpty()))) {
            ic.commitText(s, 1)
            word.append(ch)
            lastCorrection = null
            skipCorrect = null
            canDoubleSpace = false
            afterTyped(false)
            updateSuggestions()
            return
        }

        if (ch != null && (ch == ' ' || SEPARATORS.indexOf(ch) >= 0)) {
            handleSeparator(ic, s)
            return
        }

        ic.commitText(s, 1)
        word.setLength(0)
        lastCorrection = null
        canDoubleSpace = false
        afterTyped(true)
        clearSuggestions()
    }

    private fun handleSeparator(ic: android.view.inputmethod.InputConnection, sep: String) {
        val now = SystemClock.uptimeMillis()
        val w = word.toString()

        // double space -> ". "
        if (sep == " " && w.isEmpty() && canDoubleSpace && now - lastSpaceTime < 600) {
            ic.beginBatchEdit()
            ic.deleteSurroundingText(1, 0)
            ic.commitText(". ", 1)
            ic.endBatchEdit()
            canDoubleSpace = false
            lastCorrection = null
            afterTyped(true)
            clearSuggestions()
            return
        }

        val fixed = if (w.isNotEmpty()) autoCorrectFor(w) else null
        if (fixed != null && fixed != w) {
            ic.beginBatchEdit()
            ic.deleteSurroundingText(w.length, 0)
            ic.commitText(fixed + sep, 1)
            ic.endBatchEdit()
            lastCorrection = Correction(w, fixed, sep)
        } else {
            ic.commitText(sep, 1)
            lastCorrection = null
        }
        canDoubleSpace = sep == " " && w.isNotEmpty()
        lastSpaceTime = now
        word.setLength(0)
        afterTyped(true)
        clearSuggestions()
    }

    private fun autoCorrectFor(w: String): String? {
        if (!autocorrectOn || !suggestionsAllowed || symbols) return null
        if (w.length < 3 || w[0].isUpperCase()) return null
        if (w == skipCorrect) return null
        val lw = norm(w)
        if (userWords.contains(lw)) return null
        val fix: String? = if (suggestFor == w) {
            autoFix
        } else {
            val d = dicts[lang.code]
            if (d == null || !d.ready) null else computeSuggestions(d, w).autoFix
        }
        return fix
    }

    private fun afterTyped(checkCap: Boolean) {
        if (symbols) return
        if (shift == Shift.ON) shift = Shift.OFF
        if (checkCap) autoCapIfNeeded()
        refreshShift()
    }

    private fun autoCapIfNeeded() {
        if (shift == Shift.CAPS) return
        if (!prefs.getBoolean("autocap", true)) return
        val ei = currentInputEditorInfo ?: return
        val caps = currentInputConnection?.getCursorCapsMode(ei.inputType) ?: 0
        if (caps != 0) shift = Shift.ON
    }

    private fun backspace() {
        val ic = currentInputConnection ?: return
        lastOwnEdit = SystemClock.uptimeMillis()

        // right after an auto-correction: undo it and keep what the user typed
        val lc = lastCorrection
        if (lc != null && word.isEmpty()) {
            ic.beginBatchEdit()
            ic.deleteSurroundingText(lc.fixed.length + lc.sep.length, 0)
            ic.commitText(lc.original, 1)
            ic.endBatchEdit()
            word.append(lc.original)
            skipCorrect = lc.original
            lastCorrection = null
            canDoubleSpace = false
            updateSuggestions()
            return
        }
        lastCorrection = null
        canDoubleSpace = false

        val sel = ic.getSelectedText(0)
        if (!sel.isNullOrEmpty()) {
            ic.commitText("", 1)
            word.setLength(0)
            clearSuggestions()
        } else {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
            if (word.isNotEmpty()) {
                word.setLength(word.length - 1)
                updateSuggestions()
            } else {
                // we deleted into earlier text: re-read the current word a moment later
                handler.removeCallbacks(resyncRun)
                handler.postDelayed(resyncRun, 300)
            }
        }
        if (!symbols && word.isEmpty()) {
            if (shift != Shift.CAPS) {
                shift = Shift.OFF
                autoCapIfNeeded()
            }
            refreshShift()
        }
    }

    private fun replaceLast(alt: String) {
        val ic = currentInputConnection ?: return
        lastOwnEdit = SystemClock.uptimeMillis()
        val prev = ic.getTextBeforeCursor(1, 0)?.toString() ?: ""
        val up = prev.isNotEmpty() && prev[0].isUpperCase()
        ic.beginBatchEdit()
        ic.deleteSurroundingText(1, 0)
        ic.commitText(if (up) alt.uppercase() else alt, 1)
        ic.endBatchEdit()
        if (word.isNotEmpty()) word.setLength(word.length - 1)
        if (alt[0].isLetter()) word.append(if (up) alt.uppercase() else alt)
        lastCorrection = null
        updateSuggestions()
    }

    private fun pressEnter() {
        val ic = currentInputConnection ?: return
        lastOwnEdit = SystemClock.uptimeMillis()
        val w = word.toString()
        if (w.isNotEmpty()) {
            val fixed = autoCorrectFor(w)
            if (fixed != null && fixed != w) {
                ic.beginBatchEdit()
                ic.deleteSurroundingText(w.length, 0)
                ic.commitText(fixed, 1)
                ic.endBatchEdit()
            }
        }
        word.setLength(0)
        lastCorrection = null
        canDoubleSpace = false
        clearSuggestions()
        val ei = currentInputEditorInfo
        if (ei != null) {
            val action = ei.imeOptions and EditorInfo.IME_MASK_ACTION
            val noEnterAction = (ei.imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0
            if (!noEnterAction && action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
                ic.performEditorAction(action)
                return
            }
        }
        sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        afterTyped(true)
    }

    private fun onShiftTap() {
        val now = SystemClock.uptimeMillis()
        shift = when (shift) {
            Shift.OFF -> Shift.ON
            Shift.ON -> if (now - lastShiftTap < 400) Shift.CAPS else Shift.OFF
            Shift.CAPS -> Shift.OFF
        }
        lastShiftTap = now
        refreshShift()
    }

    private fun refreshShift() {
        if (renderedShift == shift) return
        renderedShift = shift
        val p = palette ?: return
        val up = shift != Shift.OFF
        for ((tv, ch) in letterKeys) {
            val t = if (up) ch.uppercase() else ch
            if (tv.text.toString() != t) tv.text = t
        }
        val k = shiftKey ?: return
        setKeyColor(k, if (up) p.primary else p.function)
        k.icon?.setImageResource(
            when (shift) {
                Shift.OFF -> R.drawable.ic_shift
                Shift.ON -> R.drawable.ic_shift_on
                Shift.CAPS -> R.drawable.ic_caps
            }
        )
        k.icon?.setColorFilter(if (up) p.onPrimary else p.onFunction)
    }

    // ---------------------------------------------------------------- suggestions

    private fun ensureDict(l: Lang) {
        if (dicts.containsKey(l.code)) return
        val d = WordDict(applicationContext, l.asset)
        dicts[l.code] = d
        exec.execute {
            try {
                d.load()
            } catch (_: Exception) {
            }
            handler.post { updateSuggestions() }
        }
    }

    private fun resyncWord() {
        val ic = currentInputConnection
        word.setLength(0)
        lastCorrection = null
        if (ic != null && suggestOn && suggestionsAllowed) {
            val before = ic.getTextBeforeCursor(40, 0)?.toString() ?: ""
            val after = ic.getTextAfterCursor(1, 0)?.toString() ?: ""
            if (after.isEmpty() || !after[0].isLetter()) {
                var i = before.length
                while (i > 0 && (before[i - 1].isLetter() || before[i - 1] == '\'')) i--
                var start = before.substring(i)
                while (start.startsWith("'")) start = start.substring(1)
                word.append(start)
            }
        }
        updateSuggestions()
    }

    private fun clearSuggestions() {
        suggestGen++
        suggestFor = null
        autoFix = null
        for (tv in suggestCells) tv.text = ""
        paintSuggestions()
    }

    private fun updateSuggestions() {
        if (suggestCells.isEmpty()) return
        if (!suggestOn || !suggestionsAllowed || symbols || word.isEmpty()) {
            clearSuggestions()
            return
        }
        val w = word.toString()
        val d = dicts[lang.code]
        if (d == null) {
            clearSuggestions()
            return
        }
        val gen = ++suggestGen
        exec.execute {
            if (gen != suggestGen || !d.ready) return@execute
            val res = try {
                computeSuggestions(d, w)
            } catch (_: Exception) {
                null
            }
            if (res != null) {
                handler.post {
                    if (gen == suggestGen && w == word.toString()) applySuggestions(w, res)
                }
            }
        }
    }

    private fun matchCase(w: String, s: String): String {
        if (w.length > 1 && w == w.uppercase() && w != w.lowercase()) return s.uppercase()
        if (w.isNotEmpty() && w[0].isUpperCase()) return s.replaceFirstChar { it.uppercase() }
        return s
    }

    private fun computeSuggestions(d: WordDict, w: String): Sugg {
        val lw = norm(w)
        val known = d.contains(lw) || userWords.contains(lw)
        val out = ArrayList<String>()
        var fix: String? = null
        if (known) {
            out.addAll(d.complete(lw, 3))
            if (!out.contains(lw)) {
                if (out.size >= 3) out.removeAt(out.size - 1)
                out.add(lw)
            }
        } else {
            val corr = d.corrections(lw, if (lw.length >= 5) 2 else 1, 3)
            val comp = d.complete(lw, 2)
            val best = corr.firstOrNull()
            if (best != null) {
                out.add(best.word)
                if (best.dist <= 1 && lw.length >= 3) fix = best.word
                out.add(lw)
            } else {
                out.add(lw)
            }
            for (cnd in corr.drop(1)) if (out.size < 3 && !out.contains(cnd.word)) out.add(cnd.word)
            for (cnd in comp) if (out.size < 3 && !out.contains(cnd)) out.add(cnd)
        }
        val shown = out.map { if (it == lw) w else matchCase(w, it) }
        return Sugg(shown, fix?.let { matchCase(w, it) })
    }

    private fun applySuggestions(w: String, res: Sugg) {
        suggestFor = w
        autoFix = res.autoFix
        if (suggestCells.size < 3) return
        suggestCells[1].text = res.list.getOrNull(0) ?: ""
        suggestCells[0].text = res.list.getOrNull(1) ?: ""
        suggestCells[2].text = res.list.getOrNull(2) ?: ""
        paintSuggestions()
    }

    private fun paintSuggestions() {
        val p = palette ?: return
        for ((i, tv) in suggestCells.withIndex()) {
            val has = tv.text.isNotEmpty()
            val center = i == 1
            tv.typeface = if (center) Typeface.create("sans-serif-medium", Typeface.NORMAL)
            else Typeface.create("sans-serif", Typeface.NORMAL)
            tv.setTextColor(if (center) p.onFunction else p.onSurface)
            if (plus && center && has) {
                val d = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(18).toFloat()
                    setColor(p.function)
                }
                tv.background = d
            } else if (center && has) {
                tv.setTextColor(p.onSurface)
                tv.background = null
            } else {
                tv.background = null
            }
        }
    }

    private fun onSuggestionTap(i: Int) {
        val ic = currentInputConnection ?: return
        val text = suggestCells.getOrNull(i)?.text?.toString() ?: ""
        if (text.isEmpty()) return
        lastOwnEdit = SystemClock.uptimeMillis()
        val w = word.toString()
        if (w.isEmpty()) return
        ic.beginBatchEdit()
        ic.deleteSurroundingText(w.length, 0)
        ic.commitText("$text ", 1)
        ic.endBatchEdit()
        // picked the word exactly as typed: remember it so it is not "corrected" again
        if (text == w) {
            userWords.add(norm(w))
            prefs.edit().putStringSet("user_words", HashSet(userWords)).apply()
        }
        word.setLength(0)
        lastCorrection = null
        canDoubleSpace = true
        lastSpaceTime = SystemClock.uptimeMillis()
        afterTyped(true)
        clearSuggestions()
    }

    // ---------------------------------------------------------------- panels: clipboard, emoji, symbols

    private fun captureClip() {
        if (!prefs.getBoolean("clip_history", true)) return
        val cm = clipboard ?: return
        val clip = (try {
            cm.primaryClip
        } catch (_: Exception) {
            null
        }) ?: return
        if (clip.itemCount == 0) return
        val extras = clip.description.extras
        if (extras != null && extras.getBoolean("android.content.extra.IS_SENSITIVE", false)) return
        val t = (try {
            clip.getItemAt(0).coerceToText(this)?.toString()
        } catch (_: Exception) {
            null
        }) ?: return
        if (t.isBlank() || t.length > 5000) return
        clipStore.add(t)
        if (panelKind == "clip") fillClipList()
    }

    private fun toggleClipPanel() {
        if (panelKind == "clip") hidePanel(true) else showClipPanel()
    }

    private fun textButton(c: Context, p: Palette, label: String, onClick: () -> Unit): TextView {
        val tv = TextView(c).apply {
            text = label
            setTextColor(p.primary)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            gravity = Gravity.CENTER
            setPadding(dp(14), 0, dp(14), 0)
        }
        val tvAttr = TypedValue()
        c.theme.resolveAttribute(android.R.attr.selectableItemBackground, tvAttr, true)
        if (tvAttr.resourceId != 0) tv.setBackgroundResource(tvAttr.resourceId)
        tv.setOnClickListener {
            feedback(it)
            onClick()
        }
        return tv
    }

    private fun attachPanel(v: View, kind: String) {
        val frame = contentFrame ?: return
        val box = keysBox ?: return
        panel?.let { frame.removeView(it) }
        panel = v
        panelKind = kind
        frame.addView(v, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        box.visibility = View.INVISIBLE
        v.alpha = 0f
        v.translationY = dp(20).toFloat()
        v.animate().alpha(1f).translationY(0f).setDuration(180).setInterpolator(DecelerateInterpolator()).start()
        tintPanelButtons()
    }

    private fun tintPanelButtons() {
        val p = palette ?: return
        ((clipBtn as? FrameLayout)?.getChildAt(0) as? ImageView)
            ?.setColorFilter(if (panelKind == "clip") p.primary else p.onSurfaceVariant)
        ((symBtn as? FrameLayout)?.getChildAt(0) as? TextView)
            ?.setTextColor(if (panelKind == "sym") p.primary else p.onSurfaceVariant)
    }

    private fun hidePanel(animate: Boolean) {
        val pv = panel
        val frame = contentFrame
        keysBox?.visibility = View.VISIBLE
        panelKind = null
        panel = null
        clipList = null
        tintPanelButtons()
        if (pv == null || frame == null) return
        if (animate) {
            pv.animate().alpha(0f).translationY(dp(20).toFloat()).setDuration(140)
                .withEndAction { frame.removeView(pv) }.start()
        } else {
            frame.removeView(pv)
        }
    }

    private fun showClipPanel() {
        val c = viewCtx ?: return
        val p = palette ?: return
        val panelV = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(p.bg)
        }
        val header = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), 0, dp(2), 0)
        }
        val title = TextView(c).apply {
            text = "Буфер обмена"
            setTextColor(p.onSurface)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        header.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(
            textButton(c, p, "Очистить") {
                clipStore.clearUnpinned()
                fillClipList()
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        header.addView(
            textButton(c, p, "ABC") { hidePanel(true) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        panelV.addView(header, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40)))

        val scroll = ScrollView(c).apply { isVerticalScrollBarEnabled = false }
        val list = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(6), dp(2), dp(6), dp(4))
        }
        scroll.addView(list, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        panelV.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        clipList = list
        attachPanel(panelV, "clip")
        fillClipList()
    }

    private fun fillClipList() {
        val c = viewCtx ?: return
        val p = palette ?: return
        val list = clipList ?: return
        list.removeAllViews()
        val clips = clipStore.load()
        val enabled = prefs.getBoolean("clip_history", true)
        if (clips.isEmpty()) {
            val tv = TextView(c).apply {
                text = if (enabled) "Пока пусто.\nСкопируйте текст, и он появится здесь."
                else "История буфера выключена в настройках."
                setTextColor(p.onSurfaceVariant)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                gravity = Gravity.CENTER
                setPadding(dp(16), dp(28), dp(16), dp(16))
            }
            list.addView(tv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            return
        }
        for (clip in clips) {
            val row = LinearLayout(c).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(14), dp(2), dp(2), dp(2))
                val bg = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(if (plus) 22 else 14).toFloat()
                    setColor(if (clip.pinned) p.function else p.letter)
                }
                background = bg
                isClickable = true
            }
            val tv = TextView(c).apply {
                text = clip.text
                maxLines = 3
                ellipsize = TextUtils.TruncateAt.END
                setTextColor(if (clip.pinned) p.onFunction else p.onSurface)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                setPadding(0, dp(8), dp(4), dp(8))
            }
            row.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

            val pin = iconButton(c, p, R.drawable.ic_pin, if (clip.pinned) p.primary else p.onSurfaceVariant) {
                clipStore.togglePin(clip.text)
                fillClipList()
            }
            pin.alpha = if (clip.pinned) 1f else 0.6f
            row.addView(pin, LinearLayout.LayoutParams(dp(40), dp(40)))
            val del = iconButton(c, p, R.drawable.ic_close, p.onSurfaceVariant) {
                clipStore.remove(clip.text)
                fillClipList()
            }
            row.addView(del, LinearLayout.LayoutParams(dp(40), dp(40)))

            row.setOnClickListener {
                feedback(it)
                pasteText(clip.text)
                hidePanel(true)
            }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.setMargins(0, dp(3), 0, dp(3))
            list.addView(row, lp)
        }
    }

    private fun pasteText(text: String) {
        val ic = currentInputConnection ?: return
        lastOwnEdit = SystemClock.uptimeMillis()
        ic.commitText(text, 1)
        word.setLength(0)
        lastCorrection = null
        canDoubleSpace = false
        afterTyped(true)
        clearSuggestions()
    }

    // ---- emoji and special symbols

    private fun split(s: String): List<String> = s.split(" ").filter { it.isNotEmpty() }

    private fun emojiCats(): List<Cat> {
        val base = emojiCache ?: run {
            val paint = android.graphics.Paint()
            fun cat(tab: String, s: String) = Cat(tab, split(s).filter { paint.hasGlyph(it) })
            val list = listOf(
                cat("😀", "😀 😃 😄 😁 😆 😅 😂 🤣 🥲 ☺️ 😊 😇 🙂 🙃 😉 😌 😍 🥰 😘 😗 😙 😚 😋 😛 😝 😜 🤪 🤨 🧐 🤓 😎 🥸 🤩 🥳 😏 😒 😞 😔 😟 😕 🙁 ☹️ 😣 😖 😫 😩 🥺 😢 😭 😤 😠 😡 🤬 🤯 😳 🥵 🥶 😱 😨 😰 😥 😓 🤗 🤔 🫣 🤭 🫢 🤫 🫠 🤥 😶 😐 😑 😬 🙄 😯 😦 😧 😮 😲 🥱 😴 🤤 😪 😵 🤐 🥴 🤢 🤮 🤧 😷 🤒 🤕 🤑 🤠 😈 👿 👹 👺 🤡 💩 👻 💀 ☠️ 👽 👾 🤖 🎃 😺 😸 😹 😻 😼 😽 🙀 😿 😾"),
                cat("👋", "👋 🤚 🖐️ ✋ 🖖 👌 🤌 🤏 ✌️ 🤞 🤟 🤘 🤙 👈 👉 👆 🖕 👇 ☝️ 👍 👎 ✊ 👊 🤛 🤜 👏 🙌 👐 🤲 🤝 🙏 ✍️ 💅 🤳 💪 🦾 🦵 🦶 👂 👃 🧠 👀 👁️ 👅 👄 🫶 🫰 🫱 🫲 👶 🧒 👦 👧 🧑 👨 👩 🧓 👴 👵 🙍 🙎 🙅 🙆 💁 🙋 🧏 🙇 🤦 🤷 💆 💇 🚶 🏃 💃 🕺 👯 🧘"),
                cat("🐶", "🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🙈 🙉 🙊 🐒 🐔 🐧 🐦 🐤 🦆 🦅 🦉 🦇 🐺 🐗 🐴 🦄 🐝 🐛 🦋 🐌 🐞 🐜 🕷️ 🦂 🐢 🐍 🦎 🐙 🦑 🦐 🦀 🐡 🐠 🐟 🐬 🐳 🐋 🦈 🐊 🐅 🐆 🦓 🦍 🐘 🦛 🐪 🦒 🐃 🐂 🐄 🐎 🐖 🐏 🐑 🐐 🦌 🐕 🐩 🐈 🐓 🦃 🕊️ 🐇 🐁 🐀 🐿️ 🦔 🌵 🎄 🌲 🌳 🌴 🌱 🌿 ☘️ 🍀 🍁 🍂 🍃 🌺 🌻 🌹 🌷 🌼 🌸 💐 🍄 🌍 🌙 ⭐ 🌟 ✨ ⚡ 🔥 🌈 ☀️ ⛅ ☁️ 🌧️ ❄️ ☃️ 💧 🌊"),
                cat("🍔", "🍏 🍎 🍐 🍊 🍋 🍌 🍉 🍇 🍓 🫐 🍈 🍒 🍑 🥭 🍍 🥥 🥝 🍅 🍆 🥑 🥦 🥒 🌶️ 🌽 🥕 🧄 🧅 🥔 🍠 🥐 🍞 🥖 🧀 🥚 🍳 🥞 🧇 🥓 🥩 🍗 🍖 🌭 🍔 🍟 🍕 🥪 🌮 🌯 🥗 🍝 🍜 🍲 🍛 🍣 🍱 🥟 🍤 🍙 🍚 🍘 🍥 🍢 🍡 🍧 🍨 🍦 🥧 🧁 🍰 🎂 🍮 🍭 🍬 🍫 🍿 🍩 🍪 🌰 🥜 🍯 🥛 ☕ 🍵 🧃 🥤 🍶 🍺 🍻 🥂 🍷 🥃 🍸 🍹 🍾 🍴 🥄"),
                cat("⚽", "⚽ 🏀 🏈 ⚾ 🥎 🎾 🏐 🏉 🎱 🏓 🏸 🥅 🏒 🏑 🏏 ⛳ 🏹 🎣 🥊 🥋 ⛸️ 🎿 🛷 🏂 🏋️ 🤸 ⛹️ 🤺 🏇 🧘 🏄 🏊 🚴 🏆 🥇 🥈 🥉 🏅 🎖️ 🎫 🎟️ 🎪 🎭 🎨 🎬 🎤 🎧 🎼 🎹 🥁 🎷 🎺 🎸 🎻 🎲 ♟️ 🎯 🎳 🎮 🎰 🧩"),
                cat("🚗", "🚗 🚕 🚙 🚌 🚎 🏎️ 🚓 🚑 🚒 🚐 🚚 🚛 🚜 🛵 🏍️ 🚲 🛴 🚂 🚆 🚇 🚊 🚉 ✈️ 🛫 🛬 🚀 🛸 🚁 ⛵ 🚤 🛳️ ⚓ 🚧 ⛽ 🚦 🗺️ 🗿 🗽 🗼 🏰 🏯 🎡 🎢 ⛲ ⛰️ 🏔️ 🗻 🌋 🏕️ 🏖️ 🏝️ 🏠 🏡 🏢 🏥 🏦 🏫 🏭 ⛪ 🕌 🌃 🌆 🌇 🌉 🌌"),
                cat("💡", "⌚ 📱 💻 ⌨️ 🖥️ 🖨️ 🖱️ 💽 💾 📀 📷 📸 📹 🎥 📞 ☎️ 📺 📻 ⏰ ⌛ ⏳ 🔋 🔌 💡 🔦 🕯️ 💸 💵 💴 💶 💷 💰 💳 💎 ⚖️ 🔧 🔨 ⚒️ 🛠️ ⛏️ 🔩 ⚙️ 🧲 🔫 💣 🧨 🔪 🗡️ ⚔️ 🛡️ 🚬 ⚰️ 🔮 📿 💈 🔭 🔬 💊 💉 🩸 🧬 🦠 🧪 🌡️ 🧹 🧺 🧻 🚽 🚿 🛁 🔑 🗝️ 🚪 🛋️ 🛏️ 🧸 🖼️ 🛍️ 🎁 🎈 🎀 🎊 🎉 ✉️ 📦 📬 📝 📁 📅 📌 📎 ✂️ 🔒 🔓 🔔 🔕"),
                cat("❤️", "❤️ 🧡 💛 💚 💙 💜 🖤 🤍 🤎 💔 ❣️ 💕 💞 💓 💗 💖 💘 💝 💯 💢 💥 💫 💦 💨 💬 💭 💤 ✅ ❌ ❎ ❓ ❔ ❕ ❗ ⭕ 🔴 🟠 🟡 🟢 🔵 🟣 ⚫ ⚪ 🟥 🟧 🟨 🟩 🟦 🟪 ⬛ ⬜ ▶️ ⏸️ ⏹️ ⏺️ ⏭️ ⏮️ 🔀 🔁 🔄 ➕ ➖ ➗ ✖️ ♾️ ‼️ ⁉️ 〰️ ©️ ®️ ™️ 🔝 🔛 🔜 🆗 🆕 🆒 🆓 🔞 ♻️ ⚠️ ⛔ 🚫 🔰 ⚜️"),
                cat("🏳️", "🏳️ 🏴 🏁 🚩 🇷🇺 🇧🇾 🇺🇦 🇰🇿 🇺🇸 🇬🇧 🇪🇺 🇩🇪 🇫🇷 🇮🇹 🇪🇸 🇵🇱 🇹🇷 🇨🇳 🇯🇵 🇰🇷 🇮🇳 🇧🇷 🇨🇦 🇦🇿 🇦🇲 🇬🇪 🇺🇿 🇲🇩 🇱🇹 🇱🇻 🇪🇪")
            )
            emojiCache = list
            list
        }
        val recent = split(prefs.getString("recent_emoji", "") ?: "")
        return listOf(Cat("🕘", recent)) + base
    }

    private fun symbolCats(): List<Cat> = listOf(
        Cat("Кириллица", split("ё Ё і І ї Ї є Є ґ Ґ ў Ў ң ү ө қ ғ һ ә ӣ ъ Ъ")),
        Cat("Валюты", split("\$ € £ ¥ ₽ ₴ ₸ ₿ ¢ ₹ ₩ ₺ ₪ ₫ ฿ ₦ ₡ ₱ ¤")),
        Cat("Математика", split("± × ÷ = ≠ ≈ ≤ ≥ < > ∞ √ ∑ ∏ ∫ ∂ ∆ ∇ ∈ ∉ ⊂ ⊃ ∪ ∩ ∧ ∨ ¬ ∀ ∃ ∅ ° ′ ″ % ‰ ¼ ½ ¾ ⅓ ⅔ ⅛ ² ³ ¹ ⁴ ⁿ ₁ ₂ ₃ ∝ ≡ ≪ ≫ ⊕ ⊗ ⊥ ∥ ∠ ∴ ∵")),
        Cat("Стрелки", split("← → ↑ ↓ ↔ ↕ ↖ ↗ ↘ ↙ ⇐ ⇒ ⇑ ⇓ ⇔ ⇄ ⇅ ↩ ↪ ↺ ↻ ➔ ➜ ➤ ➡ ⬅ ⬆ ⬇ ▲ ▼ ◀ ▶ ◄ ►")),
        Cat("Пунктуация", split("« » „ “ ” ‘ ’ ‹ › … – — ¡ ¿ § ¶ † ‡ • · ※ ‽ № @ # & * ~ ^ | \\ / _ ` ´ ¨ ¦")),
        Cat("Знаки", split("© ® ™ ℗ ℠ ℃ ℉ № ♀ ♂ ⚥ ☮ ☯ ☪ ✝ ☦ ☸ ✡ ☢ ☣ ⚠ ♨ ♻ ☎ ✆ ✉ ✂ ✎ ✓ ✔ ✕ ✖ ✗ ✘ ★ ☆ ♠ ♣ ♥ ♦ ♪ ♫ ♭ ♯ ☀ ☁ ☂ ☃ ☼ ☽ ☾ ✿ ❀ ❁ ❤ ♡ ☺ ☻ ☹")),
        Cat("Греческие", split("α β γ δ ε ζ η θ ι κ λ μ ν ξ ο π ρ σ τ υ φ χ ψ ω Γ Δ Θ Λ Ξ Π Σ Φ Ψ Ω")),
        Cat("Линии", split("─ │ ┌ ┐ └ ┘ ├ ┤ ┬ ┴ ┼ ═ ║ ╔ ╗ ╚ ╝ █ ▓ ▒ ░ ■ □ ▪ ▫ ● ○ ◆ ◇ ◉ ◎")),
        Cat("Латиница", split("à á â ã ä å æ ç è é ê ë ì í î ï ñ ò ó ô õ ö ø œ ù ú û ü ý ÿ ß ð þ ł ń ś ź ż ą ę ć č š ž ř ě ů ő ű ğ ı ş"))
    )

    private fun showGridPanel(kind: String) {
        if (panelKind == kind) {
            hidePanel(true)
            return
        }
        val c = viewCtx ?: return
        val p = palette ?: return
        clipList = null
        val emoji = kind == "emoji"
        val cats = if (emoji) emojiCats() else symbolCats()

        val panelV = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(p.bg)
        }
        val header = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val tabScroll = android.widget.HorizontalScrollView(c).apply { isHorizontalScrollBarEnabled = false }
        val tabs = LinearLayout(c).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4), 0, dp(4), 0)
        }
        tabScroll.addView(tabs, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT))
        header.addView(tabScroll, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        header.addView(
            iconButton(c, p, R.drawable.ic_backspace, p.onSurfaceVariant) { backspace() },
            LinearLayout.LayoutParams(dp(44), ViewGroup.LayoutParams.MATCH_PARENT)
        )
        header.addView(
            textButton(c, p, "ABC") { hidePanel(true) },
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
        panelV.addView(header, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(40)))

        val scroll = ScrollView(c).apply { isVerticalScrollBarEnabled = false }
        val grid = LinearLayout(c).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(2), dp(4), dp(4))
        }
        scroll.addView(grid, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        panelV.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val tabViews = ArrayList<TextView>()
        fun select(i: Int) {
            for ((j, t) in tabViews.withIndex()) {
                val on = j == i
                t.setTextColor(if (on) p.onFunction else p.onSurfaceVariant)
                t.background = if (on) GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(16).toFloat()
                    setColor(p.function)
                } else null
            }
            fillGrid(grid, cats[i].items, kind)
            scroll.scrollTo(0, 0)
        }
        cats.forEachIndexed { i, cat ->
            val tv = TextView(c).apply {
                text = cat.tab
                gravity = Gravity.CENTER
                setTextSize(TypedValue.COMPLEX_UNIT_SP, if (emoji) 20f else 14f)
                setPadding(dp(12), 0, dp(12), 0)
                minWidth = dp(40)
            }
            tv.setOnClickListener {
                feedback(it)
                select(i)
            }
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(32))
            lp.setMargins(dp(2), 0, dp(2), 0)
            tabs.addView(tv, lp)
            tabViews.add(tv)
        }
        attachPanel(panelV, kind)
        select(if (emoji && cats[0].items.isEmpty() && cats.size > 1) 1 else 0)
    }

    private fun fillGrid(grid: LinearLayout, items: List<String>, kind: String) {
        val c = viewCtx ?: return
        val p = palette ?: return
        grid.removeAllViews()
        val emoji = kind == "emoji"
        if (items.isEmpty()) {
            val tv = TextView(c).apply {
                text = "Здесь появятся недавние эмодзи"
                setTextColor(p.onSurfaceVariant)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                gravity = Gravity.CENTER
                setPadding(dp(16), dp(24), dp(16), dp(16))
            }
            grid.addView(tv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            return
        }
        val cols = 8
        val ripple = TypedValue()
        c.theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, ripple, true)
        var row: LinearLayout? = null
        var count = 0
        for (g in items) {
            if (count % cols == 0) {
                val r = LinearLayout(c).apply { orientation = LinearLayout.HORIZONTAL }
                grid.addView(r, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(46)))
                row = r
            }
            val tv = TextView(c).apply {
                text = g
                gravity = Gravity.CENTER
                setTextSize(TypedValue.COMPLEX_UNIT_SP, if (emoji) 26f else 22f)
                setTextColor(p.onSurface)
                if (ripple.resourceId != 0) setBackgroundResource(ripple.resourceId)
            }
            tv.setOnClickListener {
                feedback(it)
                pasteText(g)
                if (emoji) addRecent(g)
            }
            row?.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
            count++
        }
        while (count % cols != 0) {
            row?.addView(View(c), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
            count++
        }
    }

    private fun addRecent(e: String) {
        val cur = split(prefs.getString("recent_emoji", "") ?: "").filter { it != e }
        val next = (listOf(e) + cur).take(32)
        prefs.edit().putString("recent_emoji", next.joinToString(" ")).apply()
    }
}
