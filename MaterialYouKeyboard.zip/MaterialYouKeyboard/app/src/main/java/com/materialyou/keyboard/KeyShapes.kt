package com.materialyou.keyboard

enum class KeyKind { LETTER, FUNCTION, SHIFT, BACKSPACE, SPACE, ENTER }

/**
 * Corner radii for keys. Returned arrays are in the format of GradientDrawable.setCornerRadii:
 * [TLx, TLy, TRx, TRy, BRx, BRy, BLx, BLy], in pixels.
 * h = height of the key face in px, d = screen density.
 */
object KeyShapes {

    fun normal(kind: KeyKind, plus: Boolean, h: Float, d: Float): FloatArray {
        val pill = h / 2f
        val small = 10f * d
        if (!plus) return all(minOf(12f * d, pill))
        return when (kind) {
            KeyKind.LETTER -> all(minOf(16f * d, pill))
            KeyKind.FUNCTION, KeyKind.SPACE -> all(pill)
            KeyKind.SHIFT -> corners(pill, pill, small, small)
            KeyKind.BACKSPACE -> corners(small, pill, pill, small)
            KeyKind.ENTER -> corners(pill, small, pill, small)
        }
    }

    fun pressed(kind: KeyKind, plus: Boolean, h: Float, d: Float): FloatArray {
        val pill = h / 2f
        val small = 10f * d
        if (!plus) return all(minOf(22f * d, pill))
        return when (kind) {
            KeyKind.LETTER -> all(pill)
            KeyKind.FUNCTION, KeyKind.SHIFT, KeyKind.BACKSPACE -> all(small)
            KeyKind.SPACE -> all(14f * d)
            KeyKind.ENTER -> corners(small, pill, small, pill)
        }
    }

    private fun all(r: Float) = FloatArray(8) { r }

    private fun corners(tl: Float, tr: Float, br: Float, bl: Float) =
        floatArrayOf(tl, tl, tr, tr, br, br, bl, bl)
}
