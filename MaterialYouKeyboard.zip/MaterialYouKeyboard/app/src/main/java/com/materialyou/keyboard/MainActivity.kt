package com.materialyou.keyboard

import android.animation.ValueAnimator
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.LinearLayout
import android.widget.RadioGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.color.MaterialColors
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.slider.Slider

class MainActivity : AppCompatActivity() {

    private class PreviewKey(val view: TextView, val kind: KeyKind, val d: GradientDrawable, val cur: FloatArray)

    private lateinit var prefs: SharedPreferences
    private lateinit var imm: InputMethodManager
    private lateinit var heroTitle: TextView
    private lateinit var heroSub: TextView
    private lateinit var step1: TextView
    private lateinit var step2: TextView
    private lateinit var btnAction: MaterialButton
    private val previewKeys = ArrayList<PreviewKey>()
    private var previewH = 0f
    private var autoRow: View? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = getSharedPreferences(KeyboardService.PREFS, MODE_PRIVATE)
        imm = getSystemService(InputMethodManager::class.java)

        heroTitle = findViewById(R.id.hero_title)
        heroSub = findViewById(R.id.hero_sub)
        step1 = findViewById(R.id.step1)
        step2 = findViewById(R.id.step2)
        btnAction = findViewById(R.id.btn_action)
        btnAction.setOnClickListener {
            if (!isEnabled()) {
                startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
            } else if (!isDefault()) {
                imm.showInputMethodPicker()
            }
        }

        findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.topAppBar).apply {
            inflateMenu(R.menu.main)
            setOnMenuItemClickListener {
                startActivity(Intent(this@MainActivity, ControlCenterActivity::class.java))
                true
            }
        }

        setupPlus()
        setupRows()
        setupHeight()

        findViewById<View>(R.id.btn_clear_clips).setOnClickListener {
            ClipStore(prefs).clearAll()
            com.google.android.material.snackbar.Snackbar
                .make(it, getString(R.string.clips_cleared), com.google.android.material.snackbar.Snackbar.LENGTH_SHORT)
                .show()
        }
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) refreshStatus()
    }

    // ------------------------------------------------------------ Material You +

    private fun color(v: View, attr: Int, fallback: Int): Int = MaterialColors.getColor(v.context, attr, fallback)

    private fun setupPlus() {
        val box = findViewById<LinearLayout>(R.id.plus_preview)
        val density = resources.displayMetrics.density
        val margin = (3 * density).toInt()
        previewH = 58f * density - 2 * margin
        val plus = prefs.getBoolean("plus", false)

        val letter = color(box, com.google.android.material.R.attr.colorSurfaceContainerHighest, 0xFF3B383E.toInt())
        val onSurface = color(box, com.google.android.material.R.attr.colorOnSurface, 0xFFE6E0E9.toInt())
        val function = color(box, com.google.android.material.R.attr.colorSecondaryContainer, 0xFF4A4458.toInt())
        val onFunction = color(box, com.google.android.material.R.attr.colorOnSecondaryContainer, 0xFFE8DEF8.toInt())
        val tertiary = color(box, com.google.android.material.R.attr.colorTertiaryContainer, 0xFF633B48.toInt())
        val onTertiary = color(box, com.google.android.material.R.attr.colorOnTertiaryContainer, 0xFFFFD8E4.toInt())
        val primary = color(box, com.google.android.material.R.attr.colorPrimary, 0xFFD0BCFF.toInt())
        val onPrimary = color(box, com.google.android.material.R.attr.colorOnPrimary, 0xFF381E72.toInt())

        class Spec(val kind: KeyKind, val label: String, val w: Float, val bg: Int, val fg: Int)

        val specs = listOf(
            Spec(KeyKind.LETTER, "Q", 1f, letter, onSurface),
            Spec(KeyKind.LETTER, "W", 1f, letter, onSurface),
            Spec(KeyKind.SHIFT, "⇧", 1f, function, onFunction),
            Spec(KeyKind.SPACE, getString(R.string.space_key), 2.2f, tertiary, onTertiary),
            Spec(KeyKind.BACKSPACE, "⌫", 1f, function, onFunction),
            Spec(KeyKind.ENTER, "↵", 1f, primary, onPrimary)
        )
        for (s in specs) {
            val radii = KeyShapes.normal(s.kind, plus, previewH, density)
            val d = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                setColor(s.bg)
                cornerRadii = radii.copyOf()
            }
            val tv = TextView(this).apply {
                text = s.label
                gravity = Gravity.CENTER
                setTextColor(s.fg)
                textSize = if (s.kind == KeyKind.SPACE) 13f else 18f
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                background = d
            }
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, s.w)
            lp.setMargins(margin, margin, margin, margin)
            box.addView(tv, lp)
            previewKeys.add(PreviewKey(tv, s.kind, d, radii.copyOf()))
        }

        val sw = findViewById<MaterialSwitch>(R.id.sw_plus)
        sw.isChecked = plus
        sw.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("plus", checked).apply()
            animatePreview(checked)
        }
    }

    private fun animatePreview(plus: Boolean) {
        val density = resources.displayMetrics.density
        for (k in previewKeys) {
            val from = k.cur.copyOf()
            val to = KeyShapes.normal(k.kind, plus, previewH, density)
            ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 380
                interpolator = android.view.animation.OvershootInterpolator(1.6f)
                addUpdateListener {
                    val f = it.animatedValue as Float
                    for (i in 0 until 8) k.cur[i] = maxOf(0f, from[i] + (to[i] - from[i]) * f)
                    k.d.cornerRadii = k.cur.copyOf()
                }
                start()
            }
        }
    }

    // ------------------------------------------------------------ settings rows

    private fun addSwitch(
        container: ViewGroup,
        title: String,
        summary: String,
        key: String,
        def: Boolean,
        onChange: ((Boolean) -> Unit)? = null
    ): View {
        val row = layoutInflater.inflate(R.layout.item_switch, container, false)
        row.findViewById<TextView>(R.id.row_title).text = title
        row.findViewById<TextView>(R.id.row_summary).text = summary
        val sw = row.findViewById<MaterialSwitch>(R.id.row_switch)
        sw.isChecked = prefs.getBoolean(key, def)
        sw.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(key, checked).apply()
            onChange?.invoke(checked)
        }
        row.setOnClickListener { sw.toggle() }
        container.addView(row)
        return row
    }

    private fun setEnabledRow(row: View?, enabled: Boolean) {
        row ?: return
        row.alpha = if (enabled) 1f else 0.4f
        row.isEnabled = enabled
        row.isClickable = enabled
        row.findViewById<MaterialSwitch>(R.id.row_switch).isEnabled = enabled
    }

    private fun setupRows() {
        val input = findViewById<LinearLayout>(R.id.group_input)
        val suggestionsOn = prefs.getBoolean("suggestions", true)
        addSwitch(input, getString(R.string.sw_suggestions), getString(R.string.sw_suggestions_s), "suggestions", true) {
            setEnabledRow(autoRow, it)
        }
        autoRow = addSwitch(input, getString(R.string.sw_autocorrect), getString(R.string.sw_autocorrect_s), "autocorrect", true)
        setEnabledRow(autoRow, suggestionsOn)
        addSwitch(input, getString(R.string.sw_numrow), getString(R.string.sw_numrow_s), "number_row", true)
        addSwitch(input, getString(R.string.sw_autocap), getString(R.string.sw_autocap_s), "autocap", true)
        addSwitch(input, getString(R.string.sw_guard), getString(R.string.sw_guard_s), "touch_guard", true)
        addSwitch(input, getString(R.string.sw_hard), getString(R.string.sw_hard_s), "hard_sign_alt", false)
        addSwitch(input, getString(R.string.sw_sym123), getString(R.string.sw_sym123_s), "sym_in_123", false)
        addSwitch(input, getString(R.string.sw_globe), getString(R.string.sw_globe_s), "lang_globe", false)
        addSwitch(input, getString(R.string.sw_bigletters), getString(R.string.sw_bigletters_s), "big_letters", false)

        val feedback = findViewById<LinearLayout>(R.id.group_feedback)
        addSwitch(feedback, getString(R.string.sw_vibrate), getString(R.string.sw_vibrate_s), "vibrate", true)
        addSwitch(feedback, getString(R.string.sw_sound), getString(R.string.sw_sound_s), "sound", false)

        setupVoice()

        val clip = findViewById<LinearLayout>(R.id.group_clip)
        addSwitch(clip, getString(R.string.sw_cliphist), getString(R.string.sw_cliphist_s), "clip_history", true)
        addSwitch(clip, getString(R.string.sw_clipchip), getString(R.string.sw_clipchip_s), "clip_chip", true)
        addSwitch(clip, getString(R.string.sw_clipmask), getString(R.string.sw_clipmask_s), "clip_mask", true)
    }

    private fun setupVoice() {
        val box = findViewById<LinearLayout>(R.id.group_voice)
        val group = findViewById<RadioGroup>(R.id.voice_lang_group)
        val label = findViewById<View>(R.id.voice_lang_label)
        fun applyEnabled(on: Boolean) {
            val a = if (on) 1f else 0.4f
            label.alpha = a
            group.alpha = a
            for (i in 0 until group.childCount) group.getChildAt(i).isEnabled = on
        }
        addSwitch(box, getString(R.string.sw_voice), getString(R.string.sw_voice_s), "voice_enabled", true) {
            applyEnabled(it)
        }
        applyEnabled(prefs.getBoolean("voice_enabled", true))
        group.check(
            when (prefs.getString("voice_lang", "any")) {
                "ru" -> R.id.voice_ru
                "en" -> R.id.voice_en
                else -> R.id.voice_any
            }
        )
        group.setOnCheckedChangeListener { _, id ->
            val v = when (id) {
                R.id.voice_ru -> "ru"
                R.id.voice_en -> "en"
                else -> "any"
            }
            prefs.edit().putString("voice_lang", v).apply()
        }
        findViewById<View>(R.id.btn_mic_perm).setOnClickListener {
            startActivity(Intent(this, VoicePermissionActivity::class.java))
        }
    }

    private fun setupHeight() {
        val label = findViewById<TextView>(R.id.height_label)
        val slider = findViewById<Slider>(R.id.slider_height)
        val h = prefs.getInt("key_height", 48).coerceIn(40, 64)
        slider.value = h.toFloat()
        label.text = getString(R.string.height_label, h)
        slider.addOnChangeListener { _, value, _ ->
            val v = value.toInt()
            prefs.edit().putInt("key_height", v).apply()
            label.text = getString(R.string.height_label, v)
        }
    }

    // ------------------------------------------------------------ status

    private fun isEnabled(): Boolean =
        imm.enabledInputMethodList.any { it.packageName == packageName }

    private fun isDefault(): Boolean {
        val current = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
        return current?.startsWith("$packageName/") == true
    }

    private fun refreshStatus() {
        // settings stay locked until the keyboard is enabled and chosen as the default one
        val unlocked = isEnabled() && isDefault()
        val content = findViewById<ViewGroup>(R.id.content_root)
        for (i in 1 until content.childCount) content.getChildAt(i).visibility = if (unlocked) View.VISIBLE else View.GONE
        findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.topAppBar)
            .menu.findItem(R.id.action_cc)?.isVisible = unlocked
        findViewById<View>(R.id.btn_mic_perm).visibility =
            if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) ==
                android.content.pm.PackageManager.PERMISSION_GRANTED
            ) View.GONE else View.VISIBLE
        val enabled = isEnabled()
        val default = isDefault()
        step1.text = getString(if (enabled) R.string.step1_on else R.string.step1_off)
        step2.text = getString(if (default) R.string.step2_on else R.string.step2_off)
        when {
            !enabled -> {
                heroTitle.text = getString(R.string.setup_title)
                heroSub.text = getString(R.string.setup_sub)
                btnAction.text = getString(R.string.btn_enable)
                btnAction.visibility = View.VISIBLE
            }
            !default -> {
                heroTitle.text = getString(R.string.almost_title)
                heroSub.text = getString(R.string.almost_sub)
                btnAction.text = getString(R.string.btn_default)
                btnAction.visibility = View.VISIBLE
            }
            else -> {
                heroTitle.text = getString(R.string.active_title)
                heroSub.text = getString(R.string.active_sub)
                btnAction.visibility = View.GONE
            }
        }

        val names = assets.list("")?.toList() ?: emptyList()
        val ru = names.contains("dict_ru.txt")
        val en = names.contains("dict_en.txt")
        findViewById<TextView>(R.id.dict_status).text = getString(
            when {
                ru && en -> R.string.dict_both
                ru -> R.string.dict_ru
                en -> R.string.dict_en
                else -> R.string.dict_none
            }
        )
    }
}
