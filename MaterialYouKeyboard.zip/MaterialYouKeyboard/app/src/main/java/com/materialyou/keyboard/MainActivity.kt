package com.materialyou.keyboard

import android.animation.ValueAnimator
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.color.MaterialColors
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.slider.Slider

class MainActivity : AppCompatActivity() {

    private class PreviewKey(val view: TextView, val kind: KeyKind, val d: GradientDrawable, val cur: FloatArray)

    private lateinit var prefs: SharedPreferences
    private lateinit var imm: InputMethodManager
    private lateinit var heroTitle: TextView
    private lateinit var heroSub: TextView
    private lateinit var step1: TextView
    private lateinit var step2: TextView
    private lateinit var btnAction: MaterialButton
    private val previewKeys = ArrayList<PreviewKey>()
    private var previewH = 0f
    private var autoRow: View? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        prefs = getSharedPreferences(KeyboardService.PREFS, MODE_PRIVATE)
        imm = getSystemService(InputMethodManager::class.java)

        heroTitle = findViewById(R.id.hero_title)
        heroSub = findViewById(R.id.hero_sub)
        step1 = findViewById(R.id.step1)
        step2 = findViewById(R.id.step2)
        btnAction = findViewById(R.id.btn_action)
        btnAction.setOnClickListener {
            if (!isEnabled()) {
                startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
            } else if (!isDefault()) {
                imm.showInputMethodPicker()
            }
        }

        setupPlus()
        setupRows()
        setupHeight()

        findViewById<View>(R.id.btn_clear_clips).setOnClickListener {
            ClipStore(prefs).clearAll()
            com.google.android.material.snackbar.Snackbar
                .make(it, "История буфера очищена", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT)
                .show()
        }
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) refreshStatus()
    }

    // ------------------------------------------------------------ Material You +

    private fun color(v: View, attr: Int, fallback: Int): Int = MaterialColors.getColor(v.context, attr, fallback)

    private fun setupPlus() {
        val box = findViewById<LinearLayout>(R.id.plus_preview)
        val density = resources.displayMetrics.density
        val margin = (3 * density).toInt()
        previewH = 58f * density - 2 * margin
        val plus = prefs.getBoolean("plus", false)

        val letter = color(box, com.google.android.material.R.attr.colorSurfaceContainerHighest, 0xFF3B383E.toInt())
        val onSurface = color(box, com.google.android.material.R.attr.colorOnSurface, 0xFFE6E0E9.toInt())
        val function = color(box, com.google.android.material.R.attr.colorSecondaryContainer, 0xFF4A4458.toInt())
        val onFunction = color(box, com.google.android.material.R.attr.colorOnSecondaryContainer, 0xFFE8DEF8.toInt())
        val tertiary = color(box, com.google.android.material.R.attr.colorTertiaryContainer, 0xFF633B48.toInt())
        val onTertiary = color(box, com.google.android.material.R.attr.colorOnTertiaryContainer, 0xFFFFD8E4.toInt())
        val primary = color(box, com.google.android.material.R.attr.colorPrimary, 0xFFD0BCFF.toInt())
        val onPrimary = color(box, com.google.android.material.R.attr.colorOnPrimary, 0xFF381E72.toInt())

        class Spec(val kind: KeyKind, val label: String, val w: Float, val bg: Int, val fg: Int)

        val specs = listOf(
            Spec(KeyKind.LETTER, "Q", 1f, letter, onSurface),
            Spec(KeyKind.LETTER, "W", 1f, letter, onSurface),
            Spec(KeyKind.SHIFT, "⇧", 1f, function, onFunction),
            Spec(KeyKind.SPACE, "пробел", 2.2f, tertiary, onTertiary),
            Spec(KeyKind.BACKSPACE, "⌫", 1f, function, onFunction),
            Spec(KeyKind.ENTER, "↵", 1f, primary, onPrimary)
        )
        for (s in specs) {
            val radii = KeyShapes.normal(s.kind, plus, previewH, density)
            val d = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                setColor(s.bg)
                cornerRadii = radii.copyOf()
            }
            val tv = TextView(this).apply {
                text = s.label
                gravity = Gravity.CENTER
                setTextColor(s.fg)
                textSize = if (s.kind == KeyKind.SPACE) 13f else 18f
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                background = d
            }
            val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, s.w)
            lp.setMargins(margin, margin, margin, margin)
            box.addView(tv, lp)
            previewKeys.add(PreviewKey(tv, s.kind, d, radii.copyOf()))
        }

        val sw = findViewById<MaterialSwitch>(R.id.sw_plus)
        sw.isChecked = plus
        sw.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean("plus", checked).apply()
            animatePreview(checked)
        }
    }

    private fun animatePreview(plus: Boolean) {
        val density = resources.displayMetrics.density
        for (k in previewKeys) {
            val from = k.cur.copyOf()
            val to = KeyShapes.normal(k.kind, plus, previewH, density)
            ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 380
                interpolator = android.view.animation.OvershootInterpolator(1.6f)
                addUpdateListener {
                    val f = it.animatedValue as Float
                    for (i in 0 until 8) k.cur[i] = maxOf(0f, from[i] + (to[i] - from[i]) * f)
                    k.d.cornerRadii = k.cur.copyOf()
                }
                start()
            }
        }
    }

    // ------------------------------------------------------------ settings rows

    private fun addSwitch(
        container: ViewGroup,
        title: String,
        summary: String,
        key: String,
        def: Boolean,
        onChange: ((Boolean) -> Unit)? = null
    ): View {
        val row = layoutInflater.inflate(R.layout.item_switch, container, false)
        row.findViewById<TextView>(R.id.row_title).text = title
        row.findViewById<TextView>(R.id.row_summary).text = summary
        val sw = row.findViewById<MaterialSwitch>(R.id.row_switch)
        sw.isChecked = prefs.getBoolean(key, def)
        sw.setOnCheckedChangeListener { _, checked ->
            prefs.edit().putBoolean(key, checked).apply()
            onChange?.invoke(checked)
        }
        row.setOnClickListener { sw.toggle() }
        container.addView(row)
        return row
    }

    private fun setEnabledRow(row: View?, enabled: Boolean) {
        row ?: return
        row.alpha = if (enabled) 1f else 0.4f
        row.isEnabled = enabled
        row.isClickable = enabled
        row.findViewById<MaterialSwitch>(R.id.row_switch).isEnabled = enabled
    }

    private fun setupRows() {
        val input = findViewById<LinearLayout>(R.id.group_input)
        val suggestionsOn = prefs.getBoolean("suggestions", true)
        addSwitch(input, "Подсказки слов", "Варианты над клавиатурой", "suggestions", true) {
            setEnabledRow(autoRow, it)
        }
        autoRow = addSwitch(input, "Автозамена", "Исправлять опечатки при пробеле. Отмена: Backspace", "autocorrect", true)
        setEnabledRow(autoRow, suggestionsOn)
        addSwitch(input, "Ряд с цифрами", "Цифры над буквами", "number_row", true)
        addSwitch(input, "Заглавная в начале предложения", "Включать Shift автоматически", "autocap", true)

        val feedback = findViewById<LinearLayout>(R.id.group_feedback)
        addSwitch(feedback, "Вибрация", "Короткий отклик при нажатии", "vibrate", true)
        addSwitch(feedback, "Звук нажатия", "Системный звук клавиш", "sound", false)

        val clip = findViewById<LinearLayout>(R.id.group_clip)
        addSwitch(clip, "История буфера", "Запоминать скопированный текст. Пароли не сохраняются", "clip_history", true)
    }

    private fun setupHeight() {
        val label = findViewById<TextView>(R.id.height_label)
        val slider = findViewById<Slider>(R.id.slider_height)
        val h = prefs.getInt("key_height", 48).coerceIn(40, 64)
        slider.value = h.toFloat()
        label.text = "Высота клавиш: $h dp"
        slider.addOnChangeListener { _, value, _ ->
            val v = value.toInt()
            prefs.edit().putInt("key_height", v).apply()
            label.text = "Высота клавиш: $v dp"
        }
    }

    // ------------------------------------------------------------ status

    private fun isEnabled(): Boolean =
        imm.enabledInputMethodList.any { it.packageName == packageName }

    private fun isDefault(): Boolean {
        val current = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
        return current?.startsWith("$packageName/") == true
    }

    private fun refreshStatus() {
        val enabled = isEnabled()
        val default = isDefault()
        step1.text = if (enabled) "✓  Клавиатура включена" else "○  Включить клавиатуру в списке"
        step2.text = if (default) "✓  Выбрана по умолчанию" else "○  Выбрать её основной клавиатурой"
        when {
            !enabled -> {
                heroTitle.text = "Давайте настроим"
                heroSub.text = "Два быстрых шага, и можно печатать."
                btnAction.text = "Включить клавиатуру"
                btnAction.visibility = View.VISIBLE
            }
            !default -> {
                heroTitle.text = "Почти готово"
                heroSub.text = "Осталось выбрать YouBoard основной клавиатурой."
                btnAction.text = "Выбрать по умолчанию"
                btnAction.visibility = View.VISIBLE
            }
            else -> {
                heroTitle.text = "YouBoard активна"
                heroSub.text = "Это ваша клавиатура по умолчанию. Попробуйте её внизу."
                btnAction.visibility = View.GONE
            }
        }

        val names = assets.list("")?.toList() ?: emptyList()
        val ru = names.contains("dict_ru.txt")
        val en = names.contains("dict_en.txt")
        findViewById<TextView>(R.id.dict_status).text = when {
            ru && en -> "Словари подсказок: русский ✓, английский ✓"
            ru -> "Словари подсказок: русский ✓, английский не найден"
            en -> "Словари подсказок: английский ✓, русский не найден"
            else -> "Словари подсказок не найдены: подсказки и автозамена не будут работать. Нужен интернет при сборке."
        }
    }
}
